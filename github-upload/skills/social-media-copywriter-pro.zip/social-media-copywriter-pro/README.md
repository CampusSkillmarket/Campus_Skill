# 📱 📱 社交媒体爆款文案 (social-media-copywriter-pro)

> 营销 - SkillHub 标准格式 AI 技能

## 简介

专为在小红书、抖音售卖知识的创业大学生设计的文案创作技能。擅长打造高曝光率标题、符合人设的内容、强转化力文案，帮助用户通过售卖知识产品实现创业目标。

## 安装方式

### 方式 1：直接使用（推荐）

将 `SKILL.md` 文件内容复制到你的 AI 助手配置中即可使用。

### 方式 2：Node.js 安装

```bash
# 安装（审批通过后）
npm install @skillhub/social-media-copywriter-pro

# 使用
node -e "require('@skillhub/social-media-copywriter-pro').init()"
```

### 方式 3：下载 ZIP

```bash
# 下载（审批通过后）
curl -O https://skillhub.com/skills/social-media-copywriter-pro.zip
unzip social-media-copywriter-pro.zip
```

## 文件结构

```
social-media-copywriter-pro/
├── SKILL.md       # 主技能文件（AI 配置）
├── index.js       # 入口文件（Node.js 使用）
├── package.json   # 包信息（npm 安装）
├── README.md      # 本文件
└── CHANGELOG.md   # 变更日志
```

## 相关技能

- [study-assistant-pro](../study-assistant-pro/README.md) - 学业助手 Pro
- [business-plan-generator-pro](../business-plan-generator-pro/README.md) - 商业计划书生成器
- [web-dev-assistant](../web-dev-assistant/README.md) - 网页开发助手

## 技术支持

- 版本：1.0.0
- 更新日期：2026-03-13
- 分类：营销
- 格式：SkillHub Standard

---

© 2026 SkillHub. All rights reserved.
